notepad-angular
===

notepad-angular is a simple web app for notes management made with angular2.

Dependecies
-----------

```bash
npm install --save ng2-bs3-modal
```

Contributing
------------

ECAM 2016-2017

Othman MEJDOUBI

License
-------

This code is in the public domain.
This means you can use, modify, and distribute it without any restriction.  I
appreciate, but don't require, acknowledgement in derivative works.