import { Component } from '@angular/core';

@Component({
    selector: 'notepad-app',
    templateUrl: './app.component.html',
})

export class AppComponent  { 
	
}

